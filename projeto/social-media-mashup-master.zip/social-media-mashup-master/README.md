# Social Media Mashup #

This website is a demo for social media mashup.

### What is Social Media Mashup? ###
A social media mashup is a web page or web application that uses content from more than one source to create a single new service displayed in a single graphical interface.

### Social Media Api used in this website ###
* Reddit
* Flickr
* Tumblr
* Youtube

### Credit ###
The UI of this website is using the template from http://www.Styleshout.com

## ATTENTION ##
This website is used for the COMP3121 Class Project. Your are feel free to download the source code.
HOWEVER, please don't use it in commercial purpose.


## PLEASE CHANGE YOUR OWN API_KEY IN EACH API CALL. Thank you!!! ##
